import React from "react";

const ElementsSection = ({ addShape }) => {
  return (
    <div>
      <h2 className="text-xl font-semibold mb-2">Shapes</h2>
      <button
        className="bg-blue-500 text-white px-4 py-2 rounded mb-2 w-full"
        onClick={() => addShape("circle")}
      >
        Add Circle
      </button>
      <button
        className="bg-blue-500 text-white px-4 py-2 rounded mb-2 w-full"
        onClick={() => addShape("square")}
      >
        Add Square
      </button>
      <button
        className="bg-blue-500 text-white px-4 py-2 rounded mb-2 w-full"
        onClick={() => addShape("triangle")}
      >
        Add Triangle
      </button>
    </div>
  );
};

export default ElementsSection;
