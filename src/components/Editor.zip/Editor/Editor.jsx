import React, { useRef, useState, useEffect } from "react";
import Shape from "./Shape";
import ShapeList from "./ShapeList";
import Sidebar from "./Sidebar";
import ElementsSection from "./ElementsSection";
import ImagesSection from "./ImagesSection";
import CanvasSection from "./CanvasSection";
import ArrangeSection from "./ArrangeSection";

const Editor = () => {
  const canvasRef = useRef(null);
  const parentRef = useRef(null);
  const [canvasSize, setCanvasSize] = useState({ width: 500, height: 500 });
  const [shapes, setShapes] = useState([]);
  const [selectedShape, setSelectedShape] = useState(null);
  const [dragging, setDragging] = useState(false);
  const [resizing, setResizing] = useState(false);
  const [rotating, setRotating] = useState(false);
  const [gridImage, setGridImage] = useState(null);
  const [gridCols, setGridCols] = useState(10);
  const [gridRows, setGridRows] = useState(10);
  const [draggedIndex, setDraggedIndex] = useState(null);
  const [activeSection, setActiveSection] = useState("elements");
  const [maxCanvasWidth, setMaxCanvasWidth] = useState(800); // Default max width
  const [maxCanvasHeight, setMaxCanvasHeight] = useState(600); // Default max height

  useEffect(() => {
    const updateParentDimensions = () => {
      if (parentRef.current) {
        const parentWidth = parentRef.current.clientWidth;
        const parentHeight = parentRef.current.clientHeight;
        setMaxCanvasWidth(parentWidth);
        setMaxCanvasHeight(parentHeight);
      }
    };

    updateParentDimensions();
    window.addEventListener("resize", updateParentDimensions);
    return () => window.removeEventListener("resize", updateParentDimensions);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      shapes.forEach((shape) => {
        if (shape instanceof Shape) {
          shape.updatePosition(canvas.width, canvas.height);
          shape.draw(ctx, canvas.width, canvas.height, shape === selectedShape);
        } else {
          console.error("Invalid shape object detected:", shape);
        }
      });

      requestAnimationFrame(draw);
    };

    draw();
  }, [shapes, selectedShape]);

  const handleMouseDown = (e) => {
    if (selectedShape && selectedShape.locked) return;

    const rect = canvasRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    if (selectedShape && selectedShape.isResizeHandleClicked(x, y)) {
      setResizing(true);
      return;
    }

    if (selectedShape && isRotationHandleClicked(x, y)) {
      setRotating(true);
      return;
    }

    const clickedShape = [...shapes].reverse().find((shape) => shape.isClicked(x, y));
    setSelectedShape(clickedShape);

    if (clickedShape) {
      setDragging(true);
      clickedShape.offset = {
        x: x - clickedShape.x,
        y: y - clickedShape.y,
      };
    }
  };

  const handleMouseMove = (e) => {
    const rect = canvasRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const isShiftPressed = e.shiftKey;

    if (dragging && selectedShape) {
      selectedShape.x = x - selectedShape.offset.x;
      selectedShape.y = y - selectedShape.offset.y;
    }

    if (resizing && selectedShape) {
      const dx = x - selectedShape.x;
      const dy = y - selectedShape.y;
      const aspectRatio = selectedShape.width / selectedShape.height;

      let newWidth = Math.max(10, Math.abs(dx) * 2);
      let newHeight = Math.max(10, Math.abs(dy) * 2);

      if (isShiftPressed) {
        // Lock aspect ratio
        if (newWidth / newHeight > aspectRatio) {
          newWidth = newHeight * aspectRatio;
        } else {
          newHeight = newWidth / aspectRatio;
        }
      }

      selectedShape.width = newWidth;
      selectedShape.height = newHeight;
    }

    if (rotating && selectedShape) {
      const dx = x - selectedShape.x;
      const dy = y - selectedShape.y;
      selectedShape.rotation = Math.atan2(dy, dx);
    }
  };

  const handleMouseUp = () => {
    setDragging(false);
    setResizing(false);
    setRotating(false);
    if (selectedShape) {
      delete selectedShape.offset;
    }
  };

  const isRotationHandleClicked = (mx, my) => {
    const handleSize = 10;
    const handleX = selectedShape.x + Math.cos(selectedShape.rotation) * (selectedShape.width / 2 + handleSize);
    const handleY = selectedShape.y + Math.sin(selectedShape.rotation) * (selectedShape.height / 2 + handleSize);
    return Math.hypot(mx - handleX, my - handleY) <= handleSize;
  };

  const addShape = (type) => {
    const x = Math.random() * canvasSize.width;
    const y = Math.random() * canvasSize.height;
    const size = 20 + Math.random() * 30;
    const color = `hsl(${Math.random() * 360}, 70%, 50%)`;

    const newShape = new Shape(x, y, size, size, color, type);

    newShape.locked = false; // Initialize lock state
    setShapes((prevShapes) => [...prevShapes, newShape]);
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const img = new Image();
        img.onload = () => {
          const maxSize = Math.min(canvasSize.width, canvasSize.height) * 0.5;
          let width = img.width;
          let height = img.height;

          if (width > height) {
            if (width > maxSize) {
              height = (height / width) * maxSize;
              width = maxSize;
            }
          } else {
            if (height > maxSize) {
              width = (width / height) * maxSize;
              height = maxSize;
            }
          }

          const x = Math.random() * (canvasSize.width - width);
          const y = Math.random() * (canvasSize.height - height);

          const uniqueImageSrc = event.target.result;

          const newShape = new Shape(x, y, width, height, "transparent", "image", uniqueImageSrc);
          console.log(newShape.image.src)
          newShape.locked = false;
          setShapes((prevShapes) => [...prevShapes, newShape]);
        };
        img.src = event.target.result;
      };
      e.target.value = null;
      reader.readAsDataURL(file);
    }
  };

  const deleteShape = () => {
    if (selectedShape) {
      setShapes(shapes.filter((shape) => shape !== selectedShape));
      setSelectedShape(null);
    }
  };

  const moveShapeUp = () => {
    if (selectedShape) {
      const index = shapes.indexOf(selectedShape);
      if (index < shapes.length - 1) {
        const newShapes = [...shapes];
        newShapes.splice(index, 1);
        newShapes.splice(index + 1, 0, selectedShape);
        setShapes(newShapes);
      }
    }
  };

  const moveShapeDown = () => {
    if (selectedShape) {
      const index = shapes.indexOf(selectedShape);
      if (index > 0) {
        const newShapes = [...shapes];
        newShapes.splice(index, 1);
        newShapes.splice(index - 1, 0, selectedShape);
        setShapes(newShapes);
      }
    }
  };

  const downloadCanvas = (format = "png") => {
    const canvas = canvasRef.current;

    // Create a new canvas element with the same dimensions as the original canvas
    const exportCanvas = document.createElement("canvas");
    exportCanvas.width = canvas.width;
    exportCanvas.height = canvas.height;
    const exportCtx = exportCanvas.getContext("2d");

    // Draw the original canvas content onto the new canvas
    exportCtx.drawImage(canvas, 0, 0);

    // Export the canvas content as an image with the original quality
    const link = document.createElement("a");
    link.download = `canvas.${format}`;
    link.href = exportCanvas.toDataURL(`image/${format}`, 1.0);
    link.click();
  };

  // Convert canvas to SVG manually (basic shapes only)
  const convertCanvasToSVG = () => {
    let svgContent = `<svg xmlns="http://www.w3.org/2000/svg" width="${canvasSize.width}" height="${canvasSize.height}">`;

    shapes.forEach((shape) => {
      if (shape.type === "rectangle") {
        svgContent += `<rect x="${shape.x}" y="${shape.y}" width="${shape.width}" height="${shape.height}" fill="${shape.color}" transform="rotate(${shape.rotation}, ${shape.x}, ${shape.y})"/>`;
      } else if (shape.type === "circle") {
        svgContent += `<circle cx="${shape.x + shape.width / 2}" cy="${shape.y + shape.height / 2}" r="${shape.width / 2}" fill="${shape.color}" />`;
      } else if (shape.type === "image") {
        svgContent += `<image href="${shape.imageSrc}" x="${shape.x}" y="${shape.y}" width="${shape.width}" height="${shape.height}" />`;
      }
    });

    svgContent += `</svg>`;

    const blob = new Blob([svgContent], { type: "image/svg+xml" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.download = "canvas.svg";
    link.href = url;
    link.click();
  };

  const updateCanvasSize = () => {
    const widthInput = parseInt(document.getElementById("canvasWidth").value, 10);
    const heightInput = parseInt(document.getElementById("canvasHeight").value, 10);

    let width = widthInput;
    let height = heightInput;

    const aspectRatio = width / height;

    // Adjust width and height based on maximum allowed dimensions
    if (width > maxCanvasWidth) {
      width = maxCanvasWidth;
      height = width / aspectRatio;
    }

    if (height > maxCanvasHeight) {
      height = maxCanvasHeight;
      width = height * aspectRatio;
    }

    // Ensure the aspect ratio is maintained
    if (width > maxCanvasWidth || height > maxCanvasHeight) {
      if (width / height > maxCanvasWidth / maxCanvasHeight) {
        width = maxCanvasWidth;
        height = width / aspectRatio;
      } else {
        height = maxCanvasHeight;
        width = height * aspectRatio;
      }
    }

    console.log("New width:", width, "New height:", height); // Debugging line

    setCanvasSize({ width, height });
  };

  const generateGridImageWithWorker = () => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");

    const contentImageData = ctx.getImageData(0, 0, canvas.width, canvas.height);

    const worker = new Worker("/gridWorker.js");

    worker.postMessage({
      gridCols,
      gridRows,
      boxImageData: contentImageData.data,
      boxWidth: canvas.width,
      boxHeight: canvas.height,
    });

    worker.onmessage = function (e) {
      const { imageUrl } = e.data;
      setGridImage(URL.createObjectURL(imageUrl));
    };

    worker.onerror = function (err) {
      console.error("Worker error:", err.message);
      alert("Failed to generate grid. Check the console for details.");
    };
  };

  const showGrid = () => {
    return gridImage ? (
      <div className="flex justify-center mt-4">
        <img
          src={gridImage}
          alt="Generated Grid"
          className="border rounded"
        />
      </div>
    ) : (
      <p className="text-center mt-4">No grid generated yet.</p>
    );
  };

  const handleDragStart = (index) => {
    setDraggedIndex(index);
  };

  const handleDragOver = (e, index) => {
    e.preventDefault();
    const reversedIndex = shapes.length - 1 - index;
    if (draggedIndex === reversedIndex) return;

    const newShapes = [...shapes];
    const draggedShape = newShapes[draggedIndex];
    newShapes.splice(draggedIndex, 1);
    newShapes.splice(reversedIndex, 0, draggedShape);

    setShapes(newShapes);
    setDraggedIndex(reversedIndex);
  };

  const handleDrop = (index) => {
    setDraggedIndex(null);
  };

  const handleLockShape = (shape) => {
    shape.locked = !shape.locked;
    setShapes([...shapes]); // Force re-render
  };

  const exportShapes = () => {
    const shapesData = shapes.map((shape) => ({
      x: shape.x,
      y: shape.y,
      width: shape.width,
      height: shape.height,
      color: shape.color,
      type: shape.type,
      rotation: shape.rotation,
      locked: shape.locked,
      image: shape.type === "image" ? shape.image?.src || null : null,
    }));

    const blob = new Blob([JSON.stringify(shapesData, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.download = "shapes.flowtile";
    link.href = url;
    link.click();
  };

  const importShapes = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const shapesData = JSON.parse(event.target.result);
        const newShapes = shapesData.map((data) => {
          const newShape = new Shape(
            data.x,
            data.y,
            data.width,
            data.height,
            data.color,
            data.type,
            data.image
          );

          // Ensure images are loaded correctly
          if (data.imageSrc) {
            const img = new Image();
            img.src = data.imageSrc;
            img.onload = () => {
              newShape.image = img;
              setShapes((prevShapes) => [...prevShapes, newShape]);
            };
          } else {
            setShapes((prevShapes) => [...prevShapes, newShape]);
          }

          return newShape;
        });
      };
      reader.readAsText(file);
    }
  };

  return (
    <div ref={parentRef} className="p-4">
      <h1 className="text-2xl font-bold mb-4">Shape Editor</h1>
      <div className="flex space-x-4">
        <Sidebar onSectionClick={setActiveSection} />
        <div className="w-2/4 flex flex-col items-center">
          <div className="mb-4 flex space-x-2">
            <button onClick={() => downloadCanvas("png")}>Download HD PNG</button>

            <button
              className="bg-green-500 text-white px-4 py-2 rounded"
              onClick={exportShapes}
            >
              Export Shapes
            </button>
            <input type="file" accept=".flowtile" onChange={importShapes} className="mb-2" />
          </div>
          <canvas
            ref={canvasRef}
            width={canvasSize.width}
            height={canvasSize.height}
            className="border rounded"
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
          ></canvas>
        </div>
        <div className="w-1/4">
          {activeSection === "elements" && <ElementsSection addShape={addShape} />}
          {activeSection === "images" && <ImagesSection handleImageUpload={handleImageUpload} />}
          {activeSection === "canvas" && (
            <CanvasSection canvasSize={canvasSize} updateCanvasSize={updateCanvasSize} downloadCanvas={downloadCanvas} />
          )}
          {selectedShape && (
            <ArrangeSection
              selectedShape={selectedShape}
              moveShapeUp={moveShapeUp}
              moveShapeDown={moveShapeDown}
              deleteShape={deleteShape}
            />
          )}
          <div className="mt-4">
            <h2 className="text-xl font-semibold mb-2">Shape List</h2>
            <ShapeList
              shapes={shapes}
              onSelectShape={setSelectedShape}
              onDragStart={handleDragStart}
              onDragOver={handleDragOver}
              onDrop={handleDrop}
              onLockShape={handleLockShape}
            />
          </div>
        </div>
      </div>
      <div className="mt-4">
        <h2 className="text-xl font-semibold mb-2">Generate Grid</h2>
        <div className="flex space-x-2 mb-2">
          <label>
            Columns:
            <input
              type="number"
              value={gridCols}
              onChange={(e) => setGridCols(Math.max(1, parseInt(e.target.value)))}
              className="border rounded px-2 py-1 ml-2"
            />
          </label>
          <label>
            Rows:
            <input
              type="number"
              value={gridRows}
              onChange={(e) => setGridRows(Math.max(1, parseInt(e.target.value)))}
              className="border rounded px-2 py-1 ml-2"
            />
          </label>
        </div>
        <button
          className="bg-blue-500 text-white px-4 py-2 rounded"
          onClick={generateGridImageWithWorker}
        >
          Generate Grid
        </button>
      </div>
      {showGrid()}
    </div>
  );
};

export default Editor;
