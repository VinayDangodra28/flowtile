import React from "react";

const CanvasSection = ({ canvasSize, updateCanvasSize, downloadCanvas }) => {
  return (
    <div>
      <h2 className="text-xl font-semibold mb-2">Canvas</h2>
      <div className="mb-4 flex space-x-2">
        <label htmlFor="canvasWidth">Width:</label>
        <input id="canvasWidth" type="number" defaultValue={canvasSize.width} className="border rounded px-2 py-1" />
        <label htmlFor="canvasHeight">Height:</label>
        <input id="canvasHeight" type="number" defaultValue={canvasSize.height} className="border rounded px-2 py-1" />
        <button
          className="bg-gray-500 text-white px-4 py-2 rounded"
          onClick={updateCanvasSize}
        >
          Update Canvas Size
        </button>
        <button
          className="bg-gray-500 text-white px-4 py-2 rounded"
          onClick={() => downloadCanvas("png")}
        >
          Download Canvas
        </button>
      </div>
    </div>
  );
};

export default CanvasSection;
