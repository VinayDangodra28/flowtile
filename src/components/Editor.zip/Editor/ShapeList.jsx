import React from "react";

const ShapeList = ({ shapes, onSelectShape, onDragStart, onDragOver, onDrop, onLockShape }) => {
  return (
    <div className="shape-list">
      {shapes.map((shape, index) => (
        <div
          key={index}
          className="shape-item"
          draggable
          onDragStart={() => onDragStart(index)}
          onDragOver={(e) => onDragOver(e, index)}
          onDrop={() => onDrop(index)}
          onClick={() => onSelectShape(shape)}
          style={{ backgroundColor: shape.color, position: 'relative' }}
        >
          {shape.type}
        </div>
      ))}
    </div>
  );
};

export default ShapeList;
